#!/bin/bash

#echo " ================= Algoritmo calculo de comunicación =================== "
#echo " -------------------------- Tiempos totales"
#echo "PRIMER CLIENTE -> C1"
java  -classpath . AskRemote $1 $2


